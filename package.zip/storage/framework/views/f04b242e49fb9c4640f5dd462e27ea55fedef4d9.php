<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-4">
                <h4 class="m-0 text-dark">
                    <?php if(!request()->segment(2)): ?>
                        <?php echo e(ucfirst( 'dashboard' )); ?>

                    <?php else: ?>
                        <?php echo e(ucfirst( request()->segment(2) )); ?>

                    <?php endif; ?>
                </h4>
            </div>
            
        </div>
    </div>
</div>
<?php /**PATH E:\Diss with Pay\resources\views/partials/backend/admin-breadcrum.blade.php ENDPATH**/ ?>