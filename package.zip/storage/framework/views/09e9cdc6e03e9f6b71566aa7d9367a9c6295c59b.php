<?php if(session('success')): ?>
    <div class="row mb-2">
        <div class="col-lg-12">
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        </div>
    </div>
<?php endif; ?>
<?php if($errors->count() > 0): ?>
    <div class="alert alert-danger">
        <ul class="list-unstyled">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH E:\Diss with Pay\resources\views/partials/backend/message.blade.php ENDPATH**/ ?>