<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b> <?php echo e(config('app.name')); ?> </b>
    </div>
    <strong> &copy;</strong> <?php echo e(trans('global.allRightsReserved')); ?>

</footer>
<form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

</form>
<?php /**PATH E:\Diss with Pay\resources\views/partials/backend/footer.blade.php ENDPATH**/ ?>