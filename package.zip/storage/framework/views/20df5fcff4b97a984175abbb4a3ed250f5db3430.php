<?php $__env->startSection('content'); ?>
    <div>
        <table align="center">
            <tbody>
                <tr>
                    <td style="">
                        <table>
                            <tbody>
                                <tr>
                                    <td colspan="4" valign="top" style="">

                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top">
                                        <table align="center">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <tr>
                                                            <div>
                                                                Greetings from <?php echo e(config('app.app_name')); ?>,
                                                                <br>
                                                                <br>
                                                                Thank you for reaching out! We have successfully received your
                                                                query. Please make sure the following details are correct.
                                                                <br>
                                                                <br>
                                                        </tr>
                                                        <tr>
                                                            <th class="table_style">Name</th>
                                                            <td class="table_style"><strong><?php echo e($contact->name); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <th class="table_style">Email</th>
                                                            <td class="table_style"><strong><?php echo e($contact->email); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <th class="table_style">Number</th>
                                                            <td class="table_style"><strong><?php echo e($contact->phone); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <th class="table_style">Subject</th>
                                                            <td class="table_style"><strong><?php echo e($contact->subject); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <th class="table_style">Detail</th>
                                                            <td class="table_style"><strong><?php echo e($contact->detail); ?></strong></td>
                                                        </tr>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('email.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/email/contact.blade.php ENDPATH**/ ?>