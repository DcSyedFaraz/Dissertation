<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <div class="d-flex justify-content-between">
                                <h5 class="card-title"><?php echo e(trans('cruds.blog.title')); ?></h5>
                                <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-sm btn-primary my-auto"> <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.blog.title_singular')); ?> </a>
                            </div>

                            <!-- Table with stripped rows -->
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Title</th>
                                        
                                        
                                        <th scope="col">Created By</th>
                                        <th scope="col">Status</th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td> <?php echo e($blog->title ?? "-"); ?> </td>
                                            
                                            
                                            <td> <?php echo e($blog->user->name ?? "-"); ?> </td>
                                            <td>
                                                <?php if($blog->is_published): ?>
                                                    <span class="badge bg-success p-2 ms-2"><?php echo e('Published'); ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger p-2 ms-2"><?php echo e('Not Publish'); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group" >
                                                    <a href='<?php echo e(route('admin.blogs.show', [$blog->slug])); ?>' target="_blank" class='mx-1 btn btn-sm btn-primary'><i class='bi bi-eye'></i> </a>
                                                    <a href='<?php echo e(route('admin.blogs.edit', [$blog->id])); ?>' role='button' class='mx-1 btn btn-sm btn-info'> <i class='bi bi-pencil' ></i> </a>

                                                    <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST" onsubmit="return confirm('Are you sure? This will delete all related data also.');" style="display: inline-block;">
                                                        
                                                        <input type="hidden" name="_method" value="DELETE">
                                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                                        <button type="submit" class="mx-1 btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>