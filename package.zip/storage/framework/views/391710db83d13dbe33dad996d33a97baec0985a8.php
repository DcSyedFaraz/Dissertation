<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
    <tr>
        <td align="center" valign="middle"
            style="border-collapse:collapse;border:0;margin:0;padding:20px;color:#555559;font-family:Arial,sans-serif;font-size:12px;line-height:16px;vertical-align:middle;text-align:center;width:580px">
            <div>
                <div align="center">
                    <div style="display: table; max-width:110px;">
                       <table align="left" border="0"
                            cellspacing="0" cellpadding="0"
                            width="32" height="32"
                            style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 5px">
                            <tbody>
                                <tr style="vertical-align: top">
                                    <td align="left" valign="middle"
                                        style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                        <a href="<?php echo e($web_setting->facebook_link); ?>"
                                            title="Facebook"
                                             >
                                            <img src="https://cdn.tools.unlayer.com/social/icons/circle/facebook.png"
                                                alt="Facebook"
                                                title="Facebook"
                                                width="32"
                                                style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table align="left" border="0"
                            cellspacing="0" cellpadding="0"
                            width="32" height="32"
                            style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 5px">
                            <tbody>
                                <tr style="vertical-align: top">
                                    <td align="left" valign="middle"
                                        style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                        <a href="<?php echo e($web_setting->instagram_link); ?>"
                                            title="Instagram"
                                             >
                                            <img src="https://cdn.tools.unlayer.com/social/icons/circle/instagram.png"
                                                alt="Instagram"
                                                title="Instagram"
                                                width="32"
                                                style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table align="left" border="0"
                            cellspacing="0" cellpadding="0"
                            width="32" height="32"
                            style="width: 32px !important;height: 32px !important;display: inline-block;border-collapse: collapse;table-layout: fixed;border-spacing: 0;mso-table-lspace: 0pt;mso-table-rspace: 0pt;vertical-align: top;margin-right: 0px">
                            <tbody>
                                <tr style="vertical-align: top">
                                    <td align="left" valign="middle"
                                        style="word-break: break-word;border-collapse: collapse !important;vertical-align: top">
                                        <a href="<?php echo e($web_setting->whatsapp_no); ?>"
                                            title="WhatsApp"
                                             >
                                            <img src="https://cdn.tools.unlayer.com/social/icons/circle/whatsapp.png"
                                                alt="WhatsApp"
                                                title="WhatsApp"
                                                width="32"
                                                style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;display: block !important;border: none;height: auto;float: none;max-width: 32px !important">
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                       </div>
                </div>
                <br>
                <b><?php echo e(config('app.app_name')); ?></b>
                <br> © <?php echo e(now()->year); ?>

                <br>
            </div>
        </td>
    </tr>
</table>
</td>
</tr>
<?php /**PATH E:\Diss with Pay\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>