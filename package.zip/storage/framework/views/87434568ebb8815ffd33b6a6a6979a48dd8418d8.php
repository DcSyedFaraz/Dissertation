<div class="d-flex justify-content-between">
    <h5 class="card-title">
        <?php echo e($page_name); ?>

        
        
        <?php switch(Request::segment(count(Request::segments()))):
            case ('edit'): ?>
                <?php echo e(trans('global.edit')); ?>

                <?php break; ?>
            <?php case ('create'): ?>
                <?php echo e(trans('global.create')); ?>

                <?php break; ?>
            <?php default: ?>
        <?php endswitch; ?>
    </h5>
    <div class="my-auto">
        <a href="<?php echo e($back_link); ?>" class="btn btn-sm btn-primary"> <?php echo e(trans('global.back_to_list')); ?></a>
    </div>
</div>
<?php /**PATH E:\Diss with Pay\resources\views/partials/backend/addAndBackBtns.blade.php ENDPATH**/ ?>