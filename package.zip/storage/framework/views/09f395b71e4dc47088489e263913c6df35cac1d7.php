<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url') . Request::path()); ?>



<?php $__env->startSection('content'); ?>
<div class="bg-[#1e7a89]">

    <div class="container mx-auto lg:px-4 py-20  h-[40rem]">
        <div class="flex flex-col space-y-4 my-2 md:my-0 lg:flex-row mx-4">

            <div class="panel w-full md:w-[60%] xl:w-[30%] mx-auto ">
                <form action="<?php echo e(route('login')); ?>" method="POST" class=" bg-white border-4 border-[#6ec1e4] shadow-md rounded-lg px-4 pt-2 pb-6 flex flex-col md:ml-auto w-full space-y-2  ">
                    <?php echo csrf_field(); ?>
                    <div class="bg-primary-one py-2 px-5 rounded-t-lg">
                        <p class="text-3xl text-center text-white font-semibold">
                            <?php echo e(trans('global.login')); ?>

                        </p>
                    </div>
                    <?php if(session('success') ): ?>
                        <div class="mt-3 bg-primary-one border-t-4 border-green-700 rounded text-white shadow-md" role="alert">
                            <div class="py-2">
                                <p class="text-center  font-bold"><?php echo e(session('success')); ?></p>
                            </div>
                        </div>
                    <?php elseif(session('error')): ?>
                    <div class="mt-3 bg-white border-t-4 border-red-500 rounded  shadow-md" role="alert">
                        <div class="py-2">
                            <p class="text-center text-red-500  font-bold"><?php echo e(session('error')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="mb-2">
                        <input id="email" type="email"
                            class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                            autocomplete="email" autofocus placeholder="<?php echo e(trans('global.login_email')); ?>" name="email"
                            value="<?php echo e(old('email', null)); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong class="text-red-400"><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="">
                        <input id="password" type="password"
                            class="form-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                            autocomplete="password" autofocus placeholder="<?php echo e(trans('global.login_password')); ?>"
                            name="password" value="<?php echo e(old('password', null)); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">Please enter your password!</div>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-8">
                            <div class="icheck-primary">
                                <input type="checkbox" name="remember" id="remember">
                                <label for="remember" class=""><?php echo e(trans('global.remember_me')); ?></label>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-flat hover:shadow-md">
                        <?php echo e(trans('global.login')); ?>

                    </button>

                    <p class="text-center">
                        <span class="px-2">or continue with</span>
                    </p>

                    <div class="flex w-full space-x-1 mx-auto justify-center">
                        <a href="<?php echo e(route('register')); ?>" class=" hover:shadow-lg py-3 w-1/2 border-primary-one border-2  rounded-lg flex justify-center items-center space-x-2">
                            <img src="<?php echo e(asset('images/sign-up.png')); ?>" alt="google" width="20" height="20">
                            <span>
                                Register
                            </span>
                        </a>
                        
                    </div>
                </form>
                <?php if(Route::has('password.request')): ?>
                    <a class="mt-1 text-white float-right hover:underline-offset-7 hover:underline" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(trans('global.forgot_password')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/auth/login.blade.php ENDPATH**/ ?>