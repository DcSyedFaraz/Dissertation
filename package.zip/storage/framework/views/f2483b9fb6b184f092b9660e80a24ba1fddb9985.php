<tr>
<td class="header">

<a href="<?php echo e(route('home')); ?>" target="_blank">
    <img  src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(env('APP_NAME', config('app.name'))); ?>" style=" width:20%;">
</a>
</td>
</tr>
<?php /**PATH E:\Diss with Pay\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>