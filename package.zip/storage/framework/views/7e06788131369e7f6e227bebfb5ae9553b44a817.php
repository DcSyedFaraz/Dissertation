<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(config('app.name')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <?php if( auth()->user()->hasRoleId(2) ): ?>
            <!-- Sidebar user (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <a href="<?php echo e(route('order')); ?>" target="_blank" class="d-block btn btn-secondary btn-block text-uppercase">
                    <strong>Place new Order</strong>
                </a>
            </div>
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                    <li class="nav-item">
                        <a href="<?php echo e(route('customer.home')); ?>" class="nav-link <?php echo e(request()->routeIs('customer.home') ? 'active' : ''); ?>">
                            <i class="fas fa-fw fa-tachometer-alt nav-icon"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>

                    <li class="nav-header">ORDERS</li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('customer.orders.index')); ?>" class="nav-link <?php echo e(request()->routeIs('customer.orders.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-copy"></i>
                            <p>Orders</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('customer.invoices.index')); ?>" class="nav-link <?php echo e(request()->routeIs('customer.invoices.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-receipt"></i>
                            <p>Invoices</p>
                        </a>
                    </li>
                    <li class="nav-header">PROFILE</li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('customer.profile.index')); ?>" class="nav-link <?php echo e(request()->routeIs('customer.profile.index') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('customer.profile.change-password')); ?>" class="nav-link <?php echo e(request()->routeIs('customer.profile.change-password') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-unlock"></i>
                            <p>Change Password</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="#" class="nav-link"
                            onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <p>
                                <i class="fas fa-fw fa-sign-out-alt nav-icon">

                                </i>
                                <p><?php echo e(trans('global.logout')); ?></p>
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php else: ?>
            <!-- Admin Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
                            <i class="fas fa-fw fa-tachometer-alt nav-icon">
                            </i>
                            <p>
                                <?php echo e(trans('global.dashboard')); ?>

                            </p>
                        </a>
                    </li>
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.orders.index')); ?>">
                                <i class="fa-fw fas fa-tag nav-icon">
                                </i>
                                <p>
                                    Order's List
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.invoices.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.invoices.index')); ?>">
                                <i class="fa-fw fas fa-file nav-icon">
                                </i>
                                <p>
                                    Invoice List
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.contacts.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.contacts.index')); ?>">
                                <i class="fa-fw fas fa-phone nav-icon">
                                </i>
                                <p>
                                    Contact
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.services.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.services.index')); ?>">
                                <i class="fa-fw fas fa-cubes nav-icon">
                                </i>
                                <p>
                                    Services
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.blogs.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.blogs.index')); ?>">
                                <i class="fa-fw fas fa-copy nav-icon">
                                </i>
                                <p>
                                    Blogs
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.customers.*') ? 'actives' : ''); ?>"
                                href="<?php echo e(route('admin.customers.index')); ?>">
                                <i class="fa-fw fas fa-user-plus nav-icon"></i>
                                <p>
                                    Customers List
                                </p>
                            </a>
                        </li>
                    
                    
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.setting.*') ? 'actives' : ''); ?>"
                                href="<?php echo e(route('admin.setting.index')); ?>">
                                <i class="fa-fw fas fa-cog nav-icon"></i>
                                <p>
                                    Setting
                                </p>
                            </a>
                        </li>
                    
                    <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('profile.password.edit')); ?>">
                                    <i class="fa-fw fas fa-key nav-icon">
                                    </i>
                                    <p>
                                        <?php echo e(trans('global.change_password')); ?>

                                    </p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link"
                            onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <p>
                                <i class="fas fa-fw fa-sign-out-alt nav-icon">

                                </i>
                                <p><?php echo e(trans('global.logout')); ?></p>
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div>

</aside>
<?php /**PATH E:\Diss with Pay\resources\views/partials/menu.blade.php ENDPATH**/ ?>