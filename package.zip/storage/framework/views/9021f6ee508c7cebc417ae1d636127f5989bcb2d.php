<?php $__env->startSection('title', 'Registration'); ?>
<?php $__env->startSection('description', ''); ?>
<?php $__env->startSection('canonical', config('app.url') . Request::path()); ?>


<?php $__env->startSection('content'); ?>
<div class="bg-[#1e7a89]">

    <div class="container mx-auto lg:px-4 py-20 h-[32rem]">
        <div class="flex flex-col space-y-4 my-2 md:my-0 lg:flex-row lg:mx-4">

            <div class="panel w-full sm:w-[70%] lg:w-[35%] xl:w-[30%] mx-auto ">
                <form id="registration-form" action="<?php echo e(route('register')); ?>" method="POST"
                    class="border-4  bg-white border-[#6ec1e4] shadow-md rounded-lg px-4 pt-2 pb-6 flex flex-col md:ml-auto w-full space-y-2  ">

                    <div class="bg-primary-one py-2 px-5 rounded-t-lg text-white">
                        <p class="text-3xl text-center  font-semibold">
                            <?php echo e(trans('global.register')); ?>

                        </p>
                    </div>

                    <?php if(session()->has('status')): ?>
                        <p class="alert alert-info">
                            <?php echo e(session()->get('status')); ?>

                        </p>

                    <?php endif; ?>

                    
                    <?php echo csrf_field(); ?>

                    <div class="mb-2">
                        <input id="name" type="name"
                            class="form-input <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" required
                            autocomplete="name" autofocus placeholder="Name" name="name"
                            value="<?php echo e(old('name', null)); ?>">
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback text-red-500 font-bold">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-2">
                        <input id="email" type="email"
                            class="form-input <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" required
                            autocomplete="email" placeholder="<?php echo e(trans('global.login_email')); ?>" name="email"
                            value="<?php echo e(old('email', null)); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback text-red-500 font-bold">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-2">
                        <input type="text" id="phone" class="form-input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" value="<?php echo e(old('phone','')); ?>"/>
                        <p id="valid-msg" class="hidden font-bold text-primary-one">
                            <i class="fa fa-check-circle text-primary-one text-xl pt-2" aria-hidden="true"></i> Valid Number
                        </p>
                        <p id="error-msg" class="hidden text-red-500 font-bold"></p>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="hidden" name="phone" id="phone2" />
                    </div>

                    <button type="submit" id="submit" class="btn btn-primary btn-block btn-flat">
                        <?php echo e(__('Register')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        const phone     = document.querySelector("#phone");
        var errorMsg    = document.querySelector("#error-msg"),
        validMsg        = document.querySelector("#valid-msg");

        // here, the index maps to the error code returned from getValidationError - see readme
        var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

        // initialise plugin
        const phoneInput = window.intlTelInput(phone, {
            preferredCountries: ["GB"],
            separateDialCode : true,
            dropdownContainer : document.body,
            customPlaceholder: function(selectedCountryPlaceholder, selectedCountryData) {
                return "e.g. " + selectedCountryPlaceholder;
            },
            // initialCountry: "auto",
            geoIpLookup: function(callback) {
                $.get("https://ipinfo.io/103.244.175.33?token=1fb4fdd88d0fa0", function() {}, "jsonp").always(function(resp) {
                var countryCode = (resp && resp.country) ? resp.country : "ae";
                    // success(countryCode);
                    callback(countryCode);
                });
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
        });

        var submit = $('#registration-form').find(':submit');

        var reset = function() {
            phone.classList.remove("error");
            phone.classList.remove("error-field");
            errorMsg.innerHTML = "";
            errorMsg.classList.add("hidden");
            validMsg.classList.add("hidden");
            submit.attr("disabled", true);
            submit.addClass("btn-disabled");
        };

        // on blur: validate
        phone.addEventListener('blur', function() {
            reset();
            if (phone.value.trim()) {
                if (phoneInput.isValidNumber()) {
                    validMsg.classList.remove("hidden");
                    submit.attr("disabled", false);
                    submit.removeClass("btn-disabled");
                } else {
                    phone.classList.add("error");
                    phone.classList.add("error-field");
                    var errorCode = phoneInput.getValidationError();
                    errorMsg.innerHTML = errorMap[errorCode];

                    errorMsg.classList.remove("hidden");
                }
            }
        });

        // on keyup / change flag: reset
        phone.addEventListener('change', reset);
        phone.addEventListener('keyup', reset);

        $("#registration-form").submit(function() {
            $('#registration-form').find(':submit').attr("disabled", true);
            $('#submit').html("Submiting...");
            const phoneNumber = phoneInput.getNumber();
            $('#phone2').val(phoneNumber);
            return true;
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/auth/register.blade.php ENDPATH**/ ?>