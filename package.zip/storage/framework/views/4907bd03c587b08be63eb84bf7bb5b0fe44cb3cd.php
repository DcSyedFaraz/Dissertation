<!DOCTYPE html>
<html lang="en-us">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
   <meta name="robots" content="index,follow">

    
    <meta name="csrf-token" content="xFfFMm0UfLUjLAT6s3EW3gIZplo9RTcKeiBHRHCz">

    
    <meta name="theme-color" content="#fff"/>

    <title><?php echo $__env->yieldContent('title', env('APP_NAME')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>"/>

    
    <meta property="og:url" content="<?php echo $__env->yieldContent('canonical'); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', env('APP_NAME')); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>" />
    <meta property="og:image" content="<?php echo e(asset('imgs/logo.png')); ?>"/>

    
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', ''); ?>"/>
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('description',); ?>"/>
    <meta name="twitter:image" content="<?php echo e(asset('imgs/logo.png')); ?>"/>

    
    <link rel="canonical" href="<?php echo $__env->yieldContent('canonical', ''); ?>"/>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/frontend-customcss.css')); ?>">
    
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon.png')); ?>">
    
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/app.css')); ?>">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
    <style> .iti { width: 100%;  } </style>

    
    <script src="https://kit.fontawesome.com/2c6b599d00.js" crossorigin="anonymous"></script>

    
    <script defer src="https://unpkg.com/alpinejs@3.2.4/dist/cdn.min.js"></script>

    
    
    <?php echo $__env->yieldContent('links'); ?>

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="">

    <?php echo $__env->make('partials.frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if( !Route::is('home') ): ?>
        <?php echo $__env->make('partials.bottom-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>



    
    <?php echo $__env->make('partials.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
     <?php echo e(\TawkTo::widgetCode(config('app.tawk_to'))); ?>


    
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    
    


    

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\Diss with Pay\resources\views/layouts/web.blade.php ENDPATH**/ ?>