<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php echo $__env->make('partials.backend.addAndBackBtns', [
                                "page_name" => trans('cruds.blog.title_singular'),
                                'back_link' => route('admin.blogs.index')
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <form method="POST" action="<?php echo e(route("admin.blogs.update", [$blog->id])); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="mb-3">
                                    <label class="required" for="name"><?php echo e(trans('cruds.blog.fields.name')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?> get-slug" type="text" name="title" id="title" value="<?php echo e(old('title', $blog->title)); ?>" >
                                    <?php if($errors->has('title')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('title')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="slug"><?php echo e(trans('cruds.blog.fields.slug')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('slug') ? 'is-invalid' : ''); ?> get-slug" type="text" name="slug" id="slug" value="<?php echo e(old('slug', $blog->slug)); ?>" >
                                    <?php if($errors->has('slug')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('slug')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="canonical"><?php echo e(trans('cruds.blog.fields.canonical')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('canonical') ? 'is-invalid' : ''); ?>" type="url" readonly name="canonical" id="canonical" value="<?php echo e(old('canonical', $blog->canonical)); ?>" >
                                    <?php if($errors->has('canonical')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('canonical')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label class="required" for="meta_description"><?php echo e(trans('cruds.blog.fields.meta_description')); ?></label>
                                    <textarea name="meta_description" id="meta_description" rows="2" class="form-control <?php echo e($errors->has('meta_description') ? 'is-invalid' : ''); ?>"><?php echo e(old('meta_description', $blog->meta_description)); ?></textarea>
                                    <?php if($errors->has('meta_description')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('meta_description')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                
                                <div class="mb-3 <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
                                    <label for="image"><?php echo e(trans('cruds.blog.fields.image')); ?></label>
                                    <input class="form-control <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" type="file" name="image" id="image" value=""><?php echo e(old('iamge_path',$blog->image_path)); ?>

                                    <?php if($errors->has('image')): ?>
                                        <em class="invalid-feedback">
                                            <?php echo e($errors->first('image')); ?>

                                        </em>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <textarea class="ckeditor form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" rows="10" id="editor" name="description"><?php echo e(old('description', $blog->description)); ?></textarea>
                                    <?php if($errors->has('description')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('description')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" name="is_published" id="is_published" <?php echo e(old('descripis_publishedtion', $blog->is_published) ? "checked" : ""); ?> />
                                    <label class="form-check-label" for="is_published">Publish</label>
                                </div>

                                <div class="mb-3">
                                    <button class="btn btn-danger" type="submit">
                                        <?php echo e(trans('global.save')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <style>
            .ck-editor__editable_inline {
                min-height: 380px;
            }
        </style>
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script src="https://cdn.ckeditor.com/ckeditor5/31.1.0/classic/ckeditor.js"></script>
    <script>
            ClassicEditor
            .create( document.querySelector( '#editor' ))
                .then( editor => {
                        console.log( editor );
                } )
                .catch( error => {
                        console.error( error );
            } );
    </script>
    <script>
        $(document).ready(function() {
            $(".get-slug").on("change", function() {
                console.log($(this).val());
                $.ajax({
                    url: "<?php echo e(route('admin.blogs.getSlug')); ?>",
                    type:"POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data:{'title': $(this).val()},
                    beforeSend: function() {
                        $('#slug').val('Loading...');
                        $('#canonical').val('Loading...');
                    },
                    complete: function(){
                        // $('#contact-form').find(':submit').html('Contact Now');
                        // $('#contact-form').find(':submit').attr("disabled", false);
                    },
                    success: function(res){
                        console.log(res)
                        $('#slug').val(res);
                        $('#canonical').val( '<?php echo e(config('app.app_url')); ?>' +res);
                    },
                    error: function(res) {
                        var errors = res.responseJSON.errors;
                        console.log(errors)
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>