<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.backend.admin-breadcrum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex p-0 justify-content-between">
                            <ul class="nav nav-pills p-2">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->query('status') == null && request()->routeIs('admin.invoices.index')  ? 'active' : ''); ?>" href="<?php echo e(route('admin.invoices.index')); ?>">
                                        All Invoices
                                    </a>
                                </li>
                                <?php $__currentLoopData = $invoices_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php echo e(request()->query('status') == $invoice_status->slug ? 'active' : ''); ?>" href="<?php echo e(route('admin.invoices.index', array('status' => $invoice_status->slug) )); ?>">
                                            <?php echo e($invoice_status->name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped table-hover datatable ">
                                <thead>
                                    <tr>
                                        <th>Reference No.</th>
                                        <th>Order ID</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Currency</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($invoices)): ?>
                                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('admin.invoices.show', $invoice->ref_no)); ?>">
                                                        <strong><?php echo e(\Illuminate\Support\Str::limit(strip_tags($invoice->ref_no), 16)); ?></strong>
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.orders.show', $invoice->order->id)); ?>">
                                                        <strong><?php echo e('# '. $invoice->order->id); ?></strong>
                                                    </a>
                                                </td>
                                                <td><?php echo e(addCurrency($invoice->amount)); ?></td>
                                                <td><?php echo e(showDate($invoice->created_at)); ?></td>
                                                <td><?php echo e($invoice->currency ?? '-'); ?> </td>
                                                <td>
                                                    <?php switch($invoice->status_id):
                                                        case (4): ?>
                                                            <span class="badge <?php echo e($invoice->status->css_class); ?>"><?php echo e($invoice->status->name); ?></span>
                                                            <?php break; ?>
                                                        <?php case (5): ?>
                                                            <span class="badge <?php echo e($invoice->status->css_class); ?>"><?php echo e($invoice->status->name); ?></span>
                                                            <?php break; ?>
                                                        <?php default: ?>
                                                            <span class="badge badge-default"> Default </span>
                                                    <?php endswitch; ?>
                                                </td>
                                                <td>
                                                    
                                                        
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function() {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            // order: [
            //     [1, 'desc']
            // ],
            pageLength: 10,

        });
        let table = $('.datatable:not(.ajaxTable)').DataTable({
            buttons: dtButtons
        })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Diss with Pay\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>